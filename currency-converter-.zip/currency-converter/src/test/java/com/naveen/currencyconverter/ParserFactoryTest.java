package com.naveen.currencyconverter;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ParserFactoryTest {

    @Test
    void testGetJsonParser() throws Exception {
        assertTrue(ParserFactory.getParser("json") instanceof JSONParser, "Should return an instance of JSONParser for 'json'.");
    }

    @Test
    void testGetCsvParser() throws Exception {
        assertTrue(ParserFactory.getParser("csv") instanceof CSVParser, "Should return an instance of CSVParser for 'csv'.");
    }

    @Test
    void testGetXmlParser() throws Exception {
        assertTrue(ParserFactory.getParser("xml") instanceof XMLParser, "Should return an instance of XMLParser for 'xml'.");
    }

    @Test
    void testGetParserUnsupportedType() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            ParserFactory.getParser("unsupported");
        }, "Should throw IllegalArgumentException for unsupported file types.");
        assertEquals("Unsupported file type: unsupported", exception.getMessage(), "Error message should match for unsupported file types.");
    }
}
