package com.naveen.currencyconverter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CustomObjectMapperTest {

    @Test
    void serializeBigDecimal() throws JsonProcessingException {
        ObjectMapper mapper = CustomObjectMapper.getMapper();

        BigDecimal value1 = new BigDecimal("123.456");
        BigDecimal value2 = new BigDecimal("123.00");
        BigDecimal value3 = new BigDecimal("123");

        // Serialize BigDecimal values
        String json1 = mapper.writeValueAsString(value1);
        String json2 = mapper.writeValueAsString(value2);
        String json3 = mapper.writeValueAsString(value3);

        // Check the serialized values
        assertEquals("\"123.46\"", json1, "Should round to two decimal places");
        assertEquals("\"123\"", json2, "Should display as whole number without decimal places");
        assertEquals("\"123\"", json3, "Should display as whole number without unnecessary decimals");
    }
}
