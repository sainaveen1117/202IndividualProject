package com.naveen.currencyconverter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.io.File;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class JSONParserTest {
    @Mock
    private ObjectMapper mockMapper;

    private JSONParser jsonParser;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        jsonParser = new JSONParser(mockMapper);  // Inject the mocked ObjectMapper
    }

    @Test
    public void testParse() throws Exception {
        File inputFile = new File("path/to/input.json");
        TransactionsWrapper mockWrapper = new TransactionsWrapper();
        Transaction transaction = new Transaction(new BigDecimal("100"), "USD", "EUR");
        transaction.setConvertedAmount(new BigDecimal("94"));
        transaction.setStatus("Success");
        mockWrapper.setTransactions(Arrays.asList(transaction));

        when(mockMapper.readValue(inputFile, TransactionsWrapper.class)).thenReturn(mockWrapper);

        List<Transaction> transactions = jsonParser.parse(inputFile.getAbsolutePath());
        assertNotNull(transactions);
        assertFalse(transactions.isEmpty());
        assertEquals("USD", transactions.get(0).getOriginalCurrency());
        assertEquals("EUR", transactions.get(0).getTargetCurrency());
    }

    @Test
    public void testWrite() throws Exception {
        File outputFile = new File("path/to/output.json");
        List<Transaction> transactions = Arrays.asList(
                new Transaction(new BigDecimal("200"), "GBP", "USD")
        );
        transactions.get(0).setConvertedAmount(new BigDecimal("260"));
        transactions.get(0).setStatus("Success");

        doNothing().when(mockMapper).writeValue(eq(outputFile), any(TransactionsWrapper.class));

        jsonParser.write(outputFile.getAbsolutePath(), transactions);

        verify(mockMapper).writeValue(eq(outputFile), any(TransactionsWrapper.class));
    }
}
