package com.naveen.currencyconverter;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

class AppTest {

    private static String getTestResourcePath(String fileName) {
        return Paths.get("src", "test", "resources", fileName).toString();
    }

    @BeforeEach
    void setup() throws Exception {
        // Ensure output files are cleared before each test to prevent test contamination
        Files.deleteIfExists(Paths.get(getTestResourcePath("output.csv")));
        Files.deleteIfExists(Paths.get(getTestResourcePath("output.json")));
        Files.deleteIfExists(Paths.get(getTestResourcePath("output.xml")));
    }

    @AfterEach
    void cleanup() throws Exception {
        // Optionally clean up after tests
        Files.deleteIfExists(Paths.get(getTestResourcePath("output.csv")));
        Files.deleteIfExists(Paths.get(getTestResourcePath("output.json")));
        Files.deleteIfExists(Paths.get(getTestResourcePath("output.xml")));
    }

    @Test
    void testCsvConversion() {
        String[] args = {
                getClass().getResource("/input.csv").getPath(),
                getClass().getResource("/output.csv").getPath()
        };
        App.main(args);
        File outputFile = new File(getClass().getResource("/output.csv").getPath());
        assertTrue(outputFile.exists(), "Output CSV file should exist after processing.");
    }

    @Test
    void testJsonConversion() {
        String[] args = {
                getClass().getResource("/input.json").getPath(),
                getClass().getResource("/output.json").getPath()
        };
        App.main(args);
        File outputFile = new File(getClass().getResource("/output.json").getPath());
        assertTrue(outputFile.exists(), "Output JSON file should exist after processing.");
    }

    @Test
    void testXmlConversion() {
        String[] args = {
                getClass().getResource("/input.xml").getPath(),
                getClass().getResource("/output.xml").getPath()
        };
        App.main(args);
        File outputFile = new File(getClass().getResource("/output.xml").getPath());
        assertTrue(outputFile.exists(), "Output XML file should exist after processing.");
    }

    @Test
    void testInvalidArguments() {
        assertThrows(IllegalArgumentException.class, () -> {
            String[] args = {}; // No arguments provided
            App.main(args);
        }, "Should throw an exception due to insufficient arguments");
    }
}
