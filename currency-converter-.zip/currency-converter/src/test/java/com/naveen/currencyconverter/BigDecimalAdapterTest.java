package com.naveen.currencyconverter;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;

public class BigDecimalAdapterTest {

    private final BigDecimalAdapter adapter = new BigDecimalAdapter();

    @Test
    void testUnmarshal() throws Exception {
        String decimalString = "123.456";
        BigDecimal result = adapter.unmarshal(decimalString);
        assertEquals(new BigDecimal("123.456"), result, "Unmarshal should convert string to BigDecimal correctly.");
    }

    @Test
    void testMarshal() throws Exception {
        BigDecimal value = new BigDecimal("123.4500");
        String result = adapter.marshal(value);
        assertEquals("123.45", result, "Marshal should convert BigDecimal to string without unnecessary zeros.");

        // Testing with integer value
        value = new BigDecimal("500");
        result = adapter.marshal(value);
        assertEquals("500", result, "Marshal should handle integer values correctly without decimal point.");

        // Testing with large scale
        value = new BigDecimal("0.0000000000123456789");
        result = adapter.marshal(value);
        assertEquals("0.0000000000123456789", result, "Marshal should preserve the scale of very small numbers.");
    }
}
