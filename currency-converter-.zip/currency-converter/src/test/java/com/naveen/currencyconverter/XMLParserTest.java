package com.naveen.currencyconverter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;

class XMLParserTest {
    private XMLParser parser;
    private TransactionsWrapper wrapper;

    @BeforeEach
    void setUp() {
        parser = new XMLParser();
        wrapper = new TransactionsWrapper();
        Transaction transaction = new Transaction();
        transaction.setAmount(new BigDecimal("100"));  // Corrected to use BigDecimal
        transaction.setOriginalCurrency("USD");
        transaction.setTargetCurrency("EUR");
        transaction.setConvertedAmount(new BigDecimal("94"));
        transaction.setStatus("Success");
        wrapper.setTransactions(Arrays.asList(transaction));
    }

    @Test
    void testParse() throws Exception {
        try (MockedStatic<JAXBContext> jaxbContext = Mockito.mockStatic(JAXBContext.class)) {
            JAXBContext context = mock(JAXBContext.class);
            Unmarshaller unmarshaller = mock(Unmarshaller.class);
            jaxbContext.when(() -> JAXBContext.newInstance(TransactionsWrapper.class)).thenReturn(context);
            when(context.createUnmarshaller()).thenReturn(unmarshaller);
            when(unmarshaller.unmarshal(any(File.class))).thenReturn(wrapper);

            List<Transaction> transactions = parser.parse("dummy.xml");
            assertFalse(transactions.isEmpty(), "The list should not be empty.");
            assertEquals("USD", transactions.get(0).getOriginalCurrency(), "Currency should match.");
        }
    }

    @Test
    void testWrite() throws Exception {
        try (MockedStatic<JAXBContext> jaxbContext = Mockito.mockStatic(JAXBContext.class)) {
            JAXBContext context = mock(JAXBContext.class);
            Marshaller marshaller = mock(Marshaller.class);
            jaxbContext.when(() -> JAXBContext.newInstance(TransactionsWrapper.class)).thenReturn(context);
            when(context.createMarshaller()).thenReturn(marshaller);
            StringWriter writer = new StringWriter();
            doNothing().when(marshaller).marshal(any(), any(File.class));

            parser.write("dummy.xml", wrapper.getTransactions());
            verify(marshaller).setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            verify(marshaller).marshal(any(TransactionsWrapper.class), any(File.class));
        }
    }
}
