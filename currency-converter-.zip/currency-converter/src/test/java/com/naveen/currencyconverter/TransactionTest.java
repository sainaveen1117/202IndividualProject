package com.naveen.currencyconverter;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class TransactionTest {

    @Test
    void testAmountGetSet() {
        Transaction transaction = new Transaction();
        BigDecimal amount = new BigDecimal("100.00");
        transaction.setAmount(amount);
        assertEquals(amount, transaction.getAmount(), "Amount should match the set value.");
    }

    @Test
    void testOriginalCurrencyGetSet() {
        Transaction transaction = new Transaction();
        String originalCurrency = "USD";
        transaction.setOriginalCurrency(originalCurrency);
        assertEquals(originalCurrency, transaction.getOriginalCurrency(), "OriginalCurrency should match the set value.");
    }

    @Test
    void testTargetCurrencyGetSet() {
        Transaction transaction = new Transaction();
        String targetCurrency = "EUR";
        transaction.setTargetCurrency(targetCurrency);
        assertEquals(targetCurrency, transaction.getTargetCurrency(), "TargetCurrency should match the set value.");
    }

    @Test
    void testConvertedAmountGetSet() {
        Transaction transaction = new Transaction();
        BigDecimal convertedAmount = new BigDecimal("94.00");
        transaction.setConvertedAmount(convertedAmount);
        assertEquals(convertedAmount, transaction.getConvertedAmount(), "ConvertedAmount should match the set value.");
    }

    @Test
    void testStatusGetSet() {
        Transaction transaction = new Transaction();
        String status = "Success";
        transaction.setStatus(status);
        assertEquals(status, transaction.getStatus(), "Status should match the set value.");
    }
}
