package com.naveen.currencyconverter;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TransactionsWrapperTest {

    @Test
    void testTransactionsGetSet() {
        TransactionsWrapper wrapper = new TransactionsWrapper();
        List<Transaction> transactions = new ArrayList<>();

        // Adding sample transactions
        transactions.add(new Transaction(BigDecimal.valueOf(100), "USD", "EUR"));
        transactions.add(new Transaction(BigDecimal.valueOf(200), "EUR", "GBP"));

        wrapper.setTransactions(transactions);

        assertNotNull(wrapper.getTransactions(), "Transactions list should not be null.");
        assertEquals(2, wrapper.getTransactions().size(), "Transactions list size should be 2.");
        assertEquals("USD", wrapper.getTransactions().get(0).getOriginalCurrency(), "First transaction original currency should be USD.");
        assertEquals("EUR", wrapper.getTransactions().get(0).getTargetCurrency(), "First transaction target currency should be EUR.");
        assertEquals(BigDecimal.valueOf(100), wrapper.getTransactions().get(0).getAmount(), "First transaction amount should be 100.");
    }
}
