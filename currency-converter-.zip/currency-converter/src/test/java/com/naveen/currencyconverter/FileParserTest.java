package com.naveen.currencyconverter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class FileParserTest {
    private FileParser fileParser;
    private Transaction transaction;

    @BeforeEach
    void setUp() {
        // Mocking the FileParser interface
        fileParser = mock(FileParser.class);
        transaction = new Transaction(); // Assuming the Transaction class has a no-arg constructor
        transaction.setAmount(new BigDecimal("100"));  // Correctly using BigDecimal instead of String
        transaction.setOriginalCurrency("USD");
        transaction.setTargetCurrency("EUR");
        transaction.setConvertedAmount(new BigDecimal("94"));  // Correctly using BigDecimal instead of String
        transaction.setStatus("Success");
    }
    @Test
    void testParse() throws Exception {
        List<Transaction> expectedTransactions = new ArrayList<>();
        expectedTransactions.add(transaction);

        // Setup the mock to return a specific list of transactions
        when(fileParser.parse(anyString())).thenReturn(expectedTransactions);

        List<Transaction> resultTransactions = fileParser.parse("path/to/file");
        assertNotNull(resultTransactions);
        assertFalse(resultTransactions.isEmpty());
        assertEquals("USD", resultTransactions.get(0).getOriginalCurrency());

        // Verify parse was called with any string as argument
        verify(fileParser).parse(anyString());
    }

    @Test
    void testWrite() throws Exception {
        List<Transaction> transactionsToWrite = new ArrayList<>();
        transactionsToWrite.add(transaction);

        // Mock the behavior of write to do nothing
        doNothing().when(fileParser).write(anyString(), anyList());

        // Perform the action
        fileParser.write("path/to/output", transactionsToWrite);

        // Verify write was called with specific parameters
        verify(fileParser).write(eq("path/to/output"), anyList());
    }


    @Test
    void testExceptionHandling() throws Exception {
        // Setup the mock to throw an exception
        doThrow(new RuntimeException("Error processing file")).when(fileParser).parse(anyString());

        Exception exception = assertThrows(RuntimeException.class, () -> fileParser.parse("invalid/path"));
        assertEquals("Error processing file", exception.getMessage());
    }
}
