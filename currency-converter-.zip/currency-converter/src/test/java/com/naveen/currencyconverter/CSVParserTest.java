package com.naveen.currencyconverter;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.*;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

class CSVParserTest {
    private static final Path TEST_DIRECTORY = Path.of("test-resources");

    private CSVParser parser; // Using the custom CSVParser from your project

    @BeforeAll
    static void setup() throws IOException {
        Files.createDirectories(TEST_DIRECTORY);
    }

    @BeforeEach
    void init() {
        parser = new CSVParser(); // Initialize your CSVParser here
    }

    @AfterAll
    static void cleanup() throws IOException {
        Files.walk(TEST_DIRECTORY)
                .map(Path::toFile)
                .sorted((o1, o2) -> -o1.compareTo(o2))
                .forEach(File::delete);
    }

    @Test
    void testParse() throws Exception {
        String inputCsv = "Amount,OriginalCurrency,TargetCurrency\n1000,USD,EUR\n500,EUR,GBP";
        Path inputFile = TEST_DIRECTORY.resolve("input.csv");
        Files.writeString(inputFile, inputCsv);

        List<Transaction> transactions = parser.parse(inputFile.toString());

        assertNotNull(transactions, "The list of transactions should not be null.");
        assertEquals(2, transactions.size(), "There should be two transactions parsed.");

        Transaction transaction1 = transactions.get(0);
        assertEquals(new BigDecimal("1000"), transaction1.getAmount(), "The amount should be correctly parsed.");
        assertEquals("USD", transaction1.getOriginalCurrency(), "The original currency should be 'USD'.");
        assertEquals("EUR", transaction1.getTargetCurrency(), "The target currency should be 'EUR'.");

        Transaction transaction2 = transactions.get(1);
        assertEquals(new BigDecimal("500"), transaction2.getAmount(), "The amount should be correctly parsed.");
        assertEquals("EUR", transaction2.getOriginalCurrency(), "The original currency should be 'EUR'.");
        assertEquals("GBP", transaction2.getTargetCurrency(), "The target currency should be 'GBP'.");
    }

    @Test
    void testWrite() throws IOException {
        Path outputFile = TEST_DIRECTORY.resolve("output.csv");

        List<Transaction> transactions = List.of(
                new Transaction(new BigDecimal("1000"), "USD", "EUR"),
                new Transaction(new BigDecimal("500"), "EUR", "GBP")
        );
        transactions.get(0).setConvertedAmount(new BigDecimal("940"));
        transactions.get(0).setStatus("Success");
        transactions.get(1).setConvertedAmount(new BigDecimal("430"));
        transactions.get(1).setStatus("Success");

        parser.write(outputFile.toString(), transactions);

        assertTrue(Files.exists(outputFile), "The output file should exist.");

        List<String> lines = Files.readAllLines(outputFile);
        assertTrue(lines.contains("Amount,OriginalCurrency,TargetCurrency,ConvertedAmount,Status"),
                "The header should be correctly written.");
        assertTrue(lines.contains("1000,USD,EUR,940,Success"),
                "The first transaction should be correctly written.");
        assertTrue(lines.contains("500,EUR,GBP,430,Success"),
                "The second transaction should be correctly written.");
    }
}
