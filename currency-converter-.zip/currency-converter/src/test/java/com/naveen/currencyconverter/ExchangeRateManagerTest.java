package com.naveen.currencyconverter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.*;

class ExchangeRateManagerTest {
    private ExchangeRateManager exchangeRateManager;

    @BeforeEach
    void setUp() {
        exchangeRateManager = ExchangeRateManager.getInstance();
    }

    @Test
    void testValidConversion() {
        BigDecimal resultUSDToEUR = exchangeRateManager.convert("USD", "EUR", BigDecimal.valueOf(100));
        assertEquals(new BigDecimal("94.00"), resultUSDToEUR.stripTrailingZeros(), "USD to EUR conversion should be correct.");

        BigDecimal resultEURToUSD = exchangeRateManager.convert("EUR", "USD", BigDecimal.valueOf(100));
        assertTrue(resultEURToUSD.compareTo(new BigDecimal("106.38")) == 0, "EUR to USD conversion should be correct.");
    }

    @Test
    void testInvalidCurrencyConversion() {
        assertThrows(IllegalArgumentException.class, () -> {
            exchangeRateManager.convert("USD", "XXX", BigDecimal.valueOf(100));
        }, "Should throw IllegalArgumentException for invalid currency code.");
    }

    @Test
    void testValidCurrencyCheck() {
        assertTrue(exchangeRateManager.isValidCurrency("USD"), "USD should be recognized as a valid currency.");
        assertFalse(exchangeRateManager.isValidCurrency("XXX"), "XXX should not be recognized as a valid currency.");
    }
}
