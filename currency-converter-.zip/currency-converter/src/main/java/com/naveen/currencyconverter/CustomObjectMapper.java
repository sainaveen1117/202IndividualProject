package com.naveen.currencyconverter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class CustomObjectMapper {

    // Inner class for BigDecimal serialization
    private static class BigDecimalSerializer extends StdSerializer<BigDecimal> {
        protected BigDecimalSerializer() {
            super(BigDecimal.class);
        }

        @Override
        public void serialize(BigDecimal value, JsonGenerator gen, SerializerProvider provider) throws IOException {
            if (value == null) {
                gen.writeNull();
            } else {
                BigDecimal normalized = value.stripTrailingZeros();
                // Adjust the scale to display a maximum of two decimal places or zero if it is a whole number.
                if (normalized.scale() > 0) {
                    gen.writeString(normalized.setScale(Math.min(2, normalized.scale()), RoundingMode.HALF_UP).toPlainString());
                } else {
                    gen.writeString(normalized.toPlainString());
                }
            }
        }
    }

    // Method to get a custom ObjectMapper with BigDecimal support
    public static ObjectMapper getMapper() {
        ObjectMapper mapper = new ObjectMapper();
        SimpleModule module = new SimpleModule("BigDecimalModule");
        module.addSerializer(BigDecimal.class, new BigDecimalSerializer());
        mapper.registerModule(module);
        return mapper;
    }
}
