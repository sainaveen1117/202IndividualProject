package com.naveen.currencyconverter;

import java.math.BigDecimal;
import java.util.List;

public class App {
    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java -jar currency-converter.jar <inputFile> <outputFile>");
            System.exit(1);
        }

        String inputFilePath = args[0];
        String outputFilePath = args[1];
        String fileType = getFileType(inputFilePath);

        try {
            FileParser parser = ParserFactory.getParser(fileType);
            List<Transaction> transactions = parser.parse(inputFilePath);

            ExchangeRateManager exchangeManager = ExchangeRateManager.getInstance();
            for (Transaction transaction : transactions) {
                String originalCurrency = transaction.getOriginalCurrency();
                String targetCurrency = transaction.getTargetCurrency();

                if (!exchangeManager.isValidCurrency(originalCurrency)) {
                    if (containsNumbers(originalCurrency)) {
                        transaction.setStatus("Invalid original currency should not contain numbers");
                    } else {
                        transaction.setStatus("Invalid original currency code");
                    }
                } else if (!exchangeManager.isValidCurrency(targetCurrency)) {
                    if (containsNumbers(targetCurrency)) {
                        transaction.setStatus("Invalid target currency should not contain numbers");
                    } else {
                        transaction.setStatus("Invalid target currency code");
                    }
                } else {
                    try {
                        BigDecimal convertedAmount = exchangeManager.convert(originalCurrency, targetCurrency, transaction.getAmount());
                        transaction.setConvertedAmount(convertedAmount);
                        transaction.setStatus("Success");
                    } catch (Exception e) {
                        transaction.setStatus("Error: " + e.getMessage());
                    }
                }
            }

            parser.write(outputFilePath, transactions);
            System.out.println("Conversion completed successfully.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static String getFileType(String filePath) {
        if (filePath.endsWith(".json")) {
            return "json";
        } else if (filePath.endsWith(".csv")) {
            return "csv";
        } else if (filePath.endsWith(".xml")) {
            return "xml";
        } else {
            throw new IllegalArgumentException("Unsupported file type");
        }
    }

    private static boolean containsNumbers(String text) {
        return text.matches(".*\\d.*");
    }
}
