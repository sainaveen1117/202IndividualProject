package com.naveen.currencyconverter;

public class ParserFactory {
    public static FileParser getParser(String fileType) throws Exception {
        switch (fileType) {
            case "json":
                return new JSONParser();
            case "csv":
                return new CSVParser();
            case "xml":
                return new XMLParser();
            default:
                throw new IllegalArgumentException("Unsupported file type: " + fileType);
        }
    }
}
