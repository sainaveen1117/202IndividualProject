package com.naveen.currencyconverter;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class CSVParser implements FileParser {

    @Override
    public List<Transaction> parse(String filePath) throws Exception {
        List<Transaction> transactions = new ArrayList<>();
        try (FileReader in = new FileReader(filePath)) {
            Iterable<CSVRecord> records = CSVFormat.DEFAULT
                    .withFirstRecordAsHeader()
                    .parse(in);
            for (CSVRecord record : records) {
                String originalCurrency = record.get("OriginalCurrency");
                String targetCurrency = record.get("TargetCurrency");
                BigDecimal amount = new BigDecimal(record.get("Amount"));
                transactions.add(new Transaction(amount, originalCurrency, targetCurrency));
            }
        }
        return transactions;
    }

    @Override
    public void write(String filePath, List<Transaction> transactions) throws IOException {
        try (FileWriter out = new FileWriter(filePath);
             CSVPrinter printer = new CSVPrinter(out, CSVFormat.DEFAULT
                     .withHeader("Amount", "OriginalCurrency", "TargetCurrency", "ConvertedAmount", "Status"))) {
            for (Transaction transaction : transactions) {
                printer.printRecord(
                        transaction.getAmount(),
                        transaction.getOriginalCurrency(),
                        transaction.getTargetCurrency(),
                        transaction.getConvertedAmount() != null ? transaction.getConvertedAmount() : "",
                        transaction.getStatus()
                );
            }
        }
    }
}
