package com.naveen.currencyconverter;

import javax.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "transactions")
@XmlAccessorType(XmlAccessType.FIELD)
public class TransactionsWrapper {

    @XmlElement(name = "transaction")
    private List<Transaction> transactions;

    // Getters and Setters
    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setTransactions(List<Transaction> transactions) {
        this.transactions = transactions;
    }
}
