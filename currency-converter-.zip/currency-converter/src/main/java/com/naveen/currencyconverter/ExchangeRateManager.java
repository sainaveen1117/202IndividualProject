package com.naveen.currencyconverter;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.math.MathContext;


public class ExchangeRateManager {
    private static ExchangeRateManager instance;
    private Map<String, BigDecimal> rates;
    private Set<String> validCurrencies = Set.of("USD", "EUR", "GBP", "INR", "AUD", "CAD", "CHF", "JPY");

    private ExchangeRateManager() {
        rates = new HashMap<>();
        // Initialize rates using BigDecimal to maintain precision
        rates.put("USD_EUR", BigDecimal.valueOf(0.94));
        rates.put("EUR_USD", BigDecimal.ONE.divide(BigDecimal.valueOf(0.94), MathContext.DECIMAL128)); // Reverse of USD_EUR

        rates.put("EUR_GBP", BigDecimal.valueOf(0.86));
        rates.put("GBP_EUR", BigDecimal.ONE.divide(BigDecimal.valueOf(0.86), MathContext.DECIMAL128)); // Reverse of EUR_GBP

        rates.put("GBP_INR", BigDecimal.valueOf(103.98));
        rates.put("INR_GBP", BigDecimal.ONE.divide(BigDecimal.valueOf(103.98), MathContext.DECIMAL128)); // Reverse of GBP_INR

        rates.put("AUD_CAD", BigDecimal.valueOf(0.89));
        rates.put("CAD_AUD", BigDecimal.ONE.divide(BigDecimal.valueOf(0.89), MathContext.DECIMAL128)); // Reverse of AUD_CAD

        rates.put("CAD_USD", BigDecimal.valueOf(0.73));
        rates.put("USD_CAD", BigDecimal.ONE.divide(BigDecimal.valueOf(0.73), MathContext.DECIMAL128)); // Reverse of CAD_USD

        rates.put("CHF_AUD", BigDecimal.valueOf(1.69));
        rates.put("AUD_CHF", BigDecimal.ONE.divide(BigDecimal.valueOf(1.69), MathContext.DECIMAL128)); // Reverse of CHF_AUD

        rates.put("USD_CHF", BigDecimal.valueOf(0.91));
        rates.put("CHF_USD", BigDecimal.ONE.divide(BigDecimal.valueOf(0.91), MathContext.DECIMAL128)); // Reverse of USD_CHF

        rates.put("JPY_USD", BigDecimal.valueOf(0.0065));
        rates.put("USD_JPY", BigDecimal.ONE.divide(BigDecimal.valueOf(0.0065), MathContext.DECIMAL128)); // Reverse of JPY_USD
    }


    public static ExchangeRateManager getInstance() {
        if (instance == null) {
            synchronized (ExchangeRateManager.class) {
                if (instance == null) {
                    instance = new ExchangeRateManager();
                }
            }
        }
        return instance;
    }

    public BigDecimal convert(String from, String to, BigDecimal amount) {
        String key = from + "_" + to;
        BigDecimal rate = rates.get(key);
        if (rate == null) {
            throw new IllegalArgumentException("No exchange rate available for " + from + " to " + to);
        }
        return amount.multiply(rate);
    }


    public boolean isValidCurrency(String currency) {
        return validCurrencies.contains(currency);
    }
}
