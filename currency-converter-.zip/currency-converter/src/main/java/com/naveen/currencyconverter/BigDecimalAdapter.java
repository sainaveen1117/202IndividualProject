package com.naveen.currencyconverter;

import javax.xml.bind.annotation.adapters.XmlAdapter;
import java.math.BigDecimal;

public class BigDecimalAdapter extends XmlAdapter<String, BigDecimal> {
    @Override
    public BigDecimal unmarshal(String v) {
        return new BigDecimal(v);
    }

    @Override
    public String marshal(BigDecimal value) {
        // Remove trailing zeros and convert to plain string if no fractional part.
        return value.scale() > 0 ? value.stripTrailingZeros().toPlainString() : value.toPlainString();
    }
}
