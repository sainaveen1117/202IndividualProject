package com.naveen.currencyconverter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.File;
import java.util.List;

public class JSONParser implements FileParser {
    private ObjectMapper mapper = CustomObjectMapper.getMapper(); // Use the custom ObjectMapper

    @Override
    public List<Transaction> parse(String filePath) throws Exception {
        TransactionsWrapper transactionsWrapper = mapper.readValue(new File(filePath), TransactionsWrapper.class);
        return transactionsWrapper.getTransactions();
    }

    @Override
    public void write(String filePath, List<Transaction> transactions) throws Exception {
        ObjectNode rootNode = mapper.createObjectNode();
        ArrayNode arrayNode = mapper.createArrayNode();
        for (Transaction transaction : transactions) {
            ObjectNode transactionNode = mapper.createObjectNode();
            transactionNode.put("Amount", transaction.getAmount().toPlainString());
            transactionNode.put("OriginalCurrency", transaction.getOriginalCurrency());
            transactionNode.put("TargetCurrency", transaction.getTargetCurrency());
            if ("Success".equals(transaction.getStatus()) && transaction.getConvertedAmount() != null) {
                transactionNode.put("ConvertedAmount", transaction.getConvertedAmount().toPlainString());
            } else {
                transactionNode.put("ConvertedAmount", "");  // Explicitly output an empty string
            }
            transactionNode.put("Status", transaction.getStatus());
            arrayNode.add(transactionNode);
        }
        rootNode.set("transactions", arrayNode);
        mapper.writerWithDefaultPrettyPrinter().writeValue(new File(filePath), rootNode);
    }
}
