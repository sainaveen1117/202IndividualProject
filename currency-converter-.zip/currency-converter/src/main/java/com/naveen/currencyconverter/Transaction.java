package com.naveen.currencyconverter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.xml.bind.annotation.*;
import java.math.BigDecimal;

@XmlAccessorType(XmlAccessType.FIELD)
public class Transaction {

    @XmlElement(name = "Amount")
    @JsonProperty("Amount")
    private BigDecimal amount;

    @XmlElement(name = "OriginalCurrency")
    @JsonProperty("OriginalCurrency")
    private String originalCurrency;

    @XmlElement(name = "TargetCurrency")
    @JsonProperty("TargetCurrency")
    private String targetCurrency;

    @XmlElement(name = "ConvertedAmount", required = false)
    @XmlJavaTypeAdapter(BigDecimalAdapter.class)
    private BigDecimal convertedAmount;

    @XmlElement(name = "Status", required = false)
    @JsonProperty("Status")
    private String status;

    // No-argument constructor for JAXB and Jackson
    public Transaction() {}

    // Constructor used by CSVParser
    public Transaction(BigDecimal amount, String originalCurrency, String targetCurrency) {
        this.amount = amount;
        this.originalCurrency = originalCurrency;
        this.targetCurrency = targetCurrency;
    }

    // Getters and Setters
    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getOriginalCurrency() {
        return originalCurrency;
    }

    public void setOriginalCurrency(String originalCurrency) {
        this.originalCurrency = originalCurrency;
    }

    public String getTargetCurrency() {
        return targetCurrency;
    }

    public void setTargetCurrency(String targetCurrency) {
        this.targetCurrency = targetCurrency;
    }

    public BigDecimal getConvertedAmount() {
        return convertedAmount;
    }

    public void setConvertedAmount(BigDecimal convertedAmount) {
        this.convertedAmount = convertedAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
