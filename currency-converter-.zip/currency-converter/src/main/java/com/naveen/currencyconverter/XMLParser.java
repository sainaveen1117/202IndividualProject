package com.naveen.currencyconverter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import java.io.File;
import java.util.List;

public class XMLParser implements FileParser {

    @Override
    public List<Transaction> parse(String filePath) throws Exception {
        JAXBContext context = JAXBContext.newInstance(TransactionsWrapper.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        TransactionsWrapper wrapper = (TransactionsWrapper) unmarshaller.unmarshal(new File(filePath));
        return wrapper.getTransactions();
    }

    @Override
    public void write(String filePath, List<Transaction> transactions) throws Exception {
        JAXBContext context = JAXBContext.newInstance(TransactionsWrapper.class);
        Marshaller marshaller = context.createMarshaller();
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

        TransactionsWrapper wrapper = new TransactionsWrapper();
        wrapper.setTransactions(transactions);
        marshaller.marshal(wrapper, new File(filePath));
    }
}
