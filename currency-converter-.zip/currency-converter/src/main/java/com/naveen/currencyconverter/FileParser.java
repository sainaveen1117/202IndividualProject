package com.naveen.currencyconverter;

import java.util.List;

public interface FileParser {
    List<Transaction> parse(String filePath) throws Exception;
    void write(String filePath, List<Transaction> transactions) throws Exception;
}
